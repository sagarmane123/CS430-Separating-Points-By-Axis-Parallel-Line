***************************************************************
Initial Setup
***************************************************************

create folder cs430.
save Project_A20379756.jar file in cs430 folder.
create folder input and greedy_output in cs430 folder.
save all testing instances in input folder. 

***************************************************************
cs430 Folder structure
***************************************************************

--->cs430
------>Project_A20379756.jar
------>output_greedy
------>input
-------->instance01
-------->instance02

***************************************************************
Run Program
***************************************************************

Open cmd
Redirect to path where Project_A20379756.jar file save (eg. cd C:\cs430)
run program by using command: Java -jar Project_A20379756.jar

***************************************************************

Note: Open output file in notepad++ or WordPad

***************************************************************