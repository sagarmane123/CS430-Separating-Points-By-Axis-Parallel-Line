package com.Separation_Point_By_Axis_Parallel_Lines;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

/**
 * <H1>Readfile</H1>
 * 
 * ReadFile read txt file and stored result in 2d array
 * 
 * @author Sagar Mane
 * @version 1.0
 * @since 28-November-2016
 * 
 */
public class ReadFile {

	public static int[][] readFile(String filename) throws IOException {
		try {
			List<String> myFileLines = Files.readAllLines(Paths.get(filename));
			// Remove first Line
			myFileLines.remove(0);
			// Remove any blank lines
			for (int i = myFileLines.size() - 1; i >= 0; i--) {
				if (myFileLines.get(i).isEmpty()) {
					myFileLines.remove(i);
				}
			}
			int[][] intArray = new int[myFileLines.size()][];

			// Iterate through each row to determine the number of columns
			for (int i = 0; i < myFileLines.size(); i++) {
				// Split the line by spaces
				String[] splitLine = myFileLines.get(i).split("\\s");

				// Declare the number of columns in the row from the split
				intArray[i] = new int[splitLine.length];
				for (int j = 0; j < splitLine.length; j++) {
					// Convert each String element to an integer
					intArray[i][j] = Integer.parseInt(splitLine[j]);
				}
			}
			return intArray;
		} catch (FileNotFoundException error) {
			throw new FileNotFoundException();
		}
	}
}