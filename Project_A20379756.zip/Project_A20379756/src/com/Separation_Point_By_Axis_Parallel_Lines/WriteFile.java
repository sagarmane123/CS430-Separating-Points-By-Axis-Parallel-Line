package com.Separation_Point_By_Axis_Parallel_Lines;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

/**
 * <H1>Write File</H1>
 * 
 * WriteFile write result on txt file
 * 
 * @author Sagar Mane
 * @version 1.0
 * @since 28-November-2016
 * 
 */
public class WriteFile {
	/**
	 * This method is used write output
	 * 
	 * @param s
	 *            This parameter is used as result for output file
	 * @param filename
	 *            This parameter is used as filename
	 */
	public static void writeFile(String s, String filename) {
		Writer writer = null;
		try {
			writer = new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream(
							"./output_greedy/" + filename + ".txt"), "utf-8"));
			String result[] = s.split("\\n");
			for (String i : result) {
				writer.append(i + "\n");
			}
		} catch (IOException ex) {
		} finally {
			try {
				writer.close();
			} catch (Exception ex) {/* ignore */
			}
		}
	}
}