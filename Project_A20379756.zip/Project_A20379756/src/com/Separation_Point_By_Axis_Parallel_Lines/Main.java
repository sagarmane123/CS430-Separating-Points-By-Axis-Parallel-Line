package com.Separation_Point_By_Axis_Parallel_Lines;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * <H1>Separating Point By Axis Parallel Lines<H1>
 * 
 * This class read txt file, implementing point separation on txt file data and
 * write result on new txt file.
 * 
 * @author Sagar Mane
 * @version 1.0
 * @since 28-November-2016
 * 
 */
public class Main {

	static double sum = 0;
	static String filename = "";

	public static void main(String[] args) throws IOException {

		String target_dir = "./input";
		File dir = new File(target_dir);
		File[] files = dir.listFiles();
		for (File f : files) {
			filename = "./input/" + f.getName();
			// count = 0;
			sum = 0;
			// result = "";
			// Read Text file
			Separating_Point.result.clear(); //change
			Separating_Point.x_arr.clear();
			ReadFile rf = new ReadFile();
			int[][] arr = rf.readFile(filename);
			Separating_Point.Divide(arr, 0, 0, arr.length, arr.length);
			String res = Separating_Point.result.size() + "\n";
			for (int i = 0; i < Separating_Point.result.size(); i++)
				res += Separating_Point.result.get(i) + "\n";

			WriteFile wf = new WriteFile();
			wf.writeFile(res,
					"greedy_solution" + filename.replaceAll("[^0-9]", ""));
		}
	}
}
