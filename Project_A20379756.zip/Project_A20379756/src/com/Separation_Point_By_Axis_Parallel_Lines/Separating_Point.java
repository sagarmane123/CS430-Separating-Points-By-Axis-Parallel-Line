package com.Separation_Point_By_Axis_Parallel_Lines;

import java.util.ArrayList;
import java.util.List;

/**
 * Separating_Point class used to separating point by horizontal and vertical
 * line
 * 
 * @author Sagar Mane
 * @version 1.0
 * @since 28-November-2016
 * 
 */
public class Separating_Point {
	static List<Integer> x_arr = new ArrayList<Integer>();
	static List<String> result = new ArrayList<String>();

	/**
	 * Divide method divides points into parts until each part contains only
	 * single point.
	 * 
	 * @param coor
	 *            This 2D array of co-ordinates
	 * @param x1
	 *            x co-ordinate of starting point
	 * @param y1
	 *            y co-ordinate of starting point
	 * @param x2
	 *            x co-ordinate of ending point
	 * @param y2
	 *            y co-ordinate of ending point
	 */
	public static void Divide(int coor[][], int x1, int y1, int x2, int y2) {
		try {
			int c1 = 0;
			int c2 = 0;
			int c3 = 0;
			int c4 = 0;

			for (int i = 0; i < coor.length; i++) {

				if (coor[i][0] > x1 && coor[i][1] > y1
						&& coor[i][0] <= ((x2 + x1) / 2)
						&& coor[i][1] <= ((y2 + y1) / 2)) {
					c1++;
					x_arr.add(coor[i][1]);
				}
			}

			if (c1 == 2) {
				int avg = (x_arr.get(0) + x_arr.get(1)) / 2;
				if ((!result.contains("h " + (avg + 0.5)))) {
					result.add("h " + (avg + 0.5));
				}
			}

			x_arr.clear();

			for (int i = 0; i < coor.length; i++) {

				if (coor[i][0] > x1 && coor[i][1] > ((y1 + y2) / 2)
						&& coor[i][0] <= ((x1 + x2) / 2) && coor[i][1] <= y2) {
					c2++;
					x_arr.add(coor[i][1]);
				}
			}

			if (c2 == 2) {
				int avg = (x_arr.get(0) + x_arr.get(1)) / 2;
				if ((!result.contains("h " + (avg + 0.5)))) {
					result.add("h " + (avg + 0.5));
				}
			}

			x_arr.clear();

			for (int i = 0; i < coor.length; i++) {

				if (coor[i][0] > ((x1 + x2) / 2)
						&& coor[i][1] > ((y2 + y1) / 2) && coor[i][0] <= x2
						&& coor[i][1] <= y2) {
					c3++;
					x_arr.add(coor[i][1]);
				}
			}

			if (c3 == 2) {
				int avg = (x_arr.get(0) + x_arr.get(1)) / 2;
				if ((!result.contains("h " + (avg + 0.5)))) {
					result.add("h " + (avg + 0.5));
				}
			}

			x_arr.clear();

			for (int i = 0; i < coor.length; i++) {

				if (coor[i][0] > ((x2 + x1) / 2) && coor[i][1] > y1
						&& coor[i][0] <= x2 && coor[i][1] <= ((y1 + y2) / 2)) {
					c4++;
					x_arr.add(coor[i][1]);
				}
			}

			if (c4 == 2) {
				int avg = (x_arr.get(0) + x_arr.get(1)) / 2;
				if ((!result.contains("h " + (avg + 0.5)))) {
					result.add("h " + (avg + 0.5));
				}
			}

			x_arr.clear();

			if (!result.contains("v " + (((x1 + x2) / 2) + 0.5))) {
				// if(c2!=0)
				{
					result.add("v " + (((x1 + x2) / 2) + 0.5));
				}
			}

			if (!result.contains("h " + (((y1 + y2) / 2) + 0.5))) {
				if (c4 != 0) {
					result.add("h " + (((y1 + y2) / 2) + 0.5));
				}
			}

			if (c1 > 2) {
				Divide(coor, x1, y1, ((x1 + x2) / 2), ((y1 + y2) / 2));
			}

			if (c2 > 2) {
				Divide(coor, x1, ((y1 + y2) / 2), ((x1 + x2) / 2), y2);
			}

			if (c3 > 2) {
				Divide(coor, ((x1 + x2) / 2), ((y1 + y2) / 2), x2, y2);
			}

			if (c4 > 2) {
				Divide(coor, ((x1 + x2) / 2), y1, x2, ((y1 + y2) / 2));
			}

		} catch (Exception e) {
			System.out.println("Error");
		}
	}
}
